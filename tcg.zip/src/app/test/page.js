export default function TestPage() {
    return (
        <div>
            <h1>Test Page</h1>
            <p>This is a test page in the app directory structure.</p>
        </div>
    );
}

-- CreateTable
CREATE TABLE `users` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `email` VARCHAR(255) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `role` VARCHAR(50) NOT NULL DEFAULT 'user',
    `subscriptionStatus` VARCHAR(50) NOT NULL DEFAULT 'inactive',
    `last_login_at` DATETIME(0) NULL,
    `discord_access_token` VARCHAR(255) NULL,
    `discord_refresh_token` VARCHAR(255) NULL,
    `google_access_token` VARCHAR(255) NULL,
    `google_refresh_token` VARCHAR(255) NULL,
    `google_scopes` VARCHAR(255) NULL,
    `registeredAt` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `is_verified` TINYINT NULL DEFAULT 0,
    `verification_code` VARCHAR(10) NULL,

    UNIQUE INDEX `email`(`email`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `pokemon_sets` (
    `id` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `series` VARCHAR(191) NOT NULL,
    `printed_total` INTEGER NULL,
    `total` INTEGER NULL,
    `legalities` JSON NULL,
    `ptcgo_code` VARCHAR(191) NULL,
    `release_date` VARCHAR(191) NOT NULL,
    `images` JSON NULL,
    `api_updated_at` DATETIME(3) NULL,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `updated_at` DATETIME(0) NOT NULL,

    UNIQUE INDEX `pokemon_sets_name_key`(`name`),
    INDEX `pokemon_sets_series_idx`(`series`),
    INDEX `pokemon_sets_release_date_idx`(`release_date`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `rarities` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(191) NOT NULL,
    `symbol` VARCHAR(20) NULL,
    `order_index` INTEGER NULL DEFAULT 0,
    `color` VARCHAR(20) NULL,
    `description` TEXT NULL,
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `updated_at` DATETIME(0) NOT NULL,

    UNIQUE INDEX `rarities_name_key`(`name`),
    INDEX `rarities_order_index_idx`(`order_index`),
    INDEX `rarities_is_active_idx`(`is_active`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `subtypes` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(191) NOT NULL,
    `category` VARCHAR(50) NOT NULL,
    `description` TEXT NULL,
    `order_index` INTEGER NULL DEFAULT 0,
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `updated_at` DATETIME(0) NOT NULL,

    UNIQUE INDEX `subtypes_name_key`(`name`),
    INDEX `subtypes_category_idx`(`category`),
    INDEX `subtypes_is_active_idx`(`is_active`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `supertypes` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(191) NOT NULL,
    `description` TEXT NULL,
    `order_index` INTEGER NULL DEFAULT 0,
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `updated_at` DATETIME(0) NOT NULL,

    UNIQUE INDEX `supertypes_name_key`(`name`),
    INDEX `supertypes_order_index_idx`(`order_index`),
    INDEX `supertypes_is_active_idx`(`is_active`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `card_types` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(50) NOT NULL,
    `category` VARCHAR(50) NOT NULL,
    `color` VARCHAR(20) NULL,
    `symbol` VARCHAR(10) NULL,
    `description` TEXT NULL,
    `weakness_to` VARCHAR(50) NULL,
    `resistant_to` VARCHAR(50) NULL,
    `super_effective` JSON NULL,
    `not_effective` JSON NULL,
    `energy_symbol` VARCHAR(255) NULL,
    `type_order` INTEGER NULL DEFAULT 0,
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `updated_at` DATETIME(0) NOT NULL,

    UNIQUE INDEX `card_types_name_key`(`name`),
    INDEX `card_types_category_idx`(`category`),
    INDEX `card_types_is_active_idx`(`is_active`),
    INDEX `card_types_type_order_idx`(`type_order`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `cards` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `set_name` VARCHAR(255) NOT NULL,
    `set_number` VARCHAR(50) NULL,
    `rarity` VARCHAR(50) NOT NULL,
    `card_type` VARCHAR(50) NULL,
    `subtype` VARCHAR(255) NULL,
    `hp` INTEGER NULL,
    `image_url` VARCHAR(500) NULL,
    `small_image_url` VARCHAR(500) NULL,
    `tcg_id` VARCHAR(255) NULL,
    `api_id` VARCHAR(100) NULL,
    `supertype` VARCHAR(50) NULL,
    `subtypes` JSON NULL,
    `set_id` VARCHAR(191) NULL,
    `rarity_id` INTEGER NULL,
    `subtype_id` INTEGER NULL,
    `supertype_id` INTEGER NULL,
    `primary_type_id` INTEGER NULL,
    `secondary_type_id` INTEGER NULL,
    `types` JSON NULL,
    `weakness_type` VARCHAR(50) NULL,
    `weakness_value` VARCHAR(20) NULL,
    `resistance_type` VARCHAR(50) NULL,
    `resistance_value` VARCHAR(20) NULL,
    `retreat_cost` JSON NULL,
    `retreat_cost_count` INTEGER NULL,
    `evolves_from` VARCHAR(255) NULL,
    `evolves_to` JSON NULL,
    `evolution_stage` VARCHAR(50) NULL,
    `pokemon_type` VARCHAR(100) NULL,
    `abilities` JSON NULL,
    `attacks` JSON NULL,
    `artist` VARCHAR(255) NULL,
    `flavor_text` TEXT NULL,
    `national_pokedex_numbers` JSON NULL,
    `regulation_mark` VARCHAR(10) NULL,
    `tcgplayer_prices` JSON NULL,
    `cardmarket_prices` JSON NULL,
    `market_price` DECIMAL(10, 2) NULL,
    `price_trend` VARCHAR(20) NULL,
    `last_price_update` DATETIME(3) NULL,
    `legalities` JSON NULL,
    `tournament_legal` BOOLEAN NOT NULL DEFAULT true,
    `banned_formats` JSON NULL,
    `condition_notes` TEXT NULL,
    `grading_company` VARCHAR(50) NULL,
    `grade_score` VARCHAR(10) NULL,
    `grade_date` DATETIME(3) NULL,
    `rarity_symbol` VARCHAR(20) NULL,
    `holographic` BOOLEAN NOT NULL DEFAULT false,
    `reverse_holo` BOOLEAN NOT NULL DEFAULT false,
    `first_edition` BOOLEAN NOT NULL DEFAULT false,
    `shadowless` BOOLEAN NOT NULL DEFAULT false,
    `promo` BOOLEAN NOT NULL DEFAULT false,
    `secret_rare` BOOLEAN NOT NULL DEFAULT false,
    `source` ENUM('API', 'MANUAL', 'MIXED') NOT NULL DEFAULT 'MANUAL',
    `api_updated_at` DATETIME(3) NULL,
    `sync_enabled` BOOLEAN NOT NULL DEFAULT true,
    `last_sync` DATETIME(3) NULL,
    `tags` JSON NULL,
    `notes` TEXT NULL,
    `featured` BOOLEAN NOT NULL DEFAULT false,
    `view_count` INTEGER NOT NULL DEFAULT 0,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `updated_at` DATETIME(0) NOT NULL,

    UNIQUE INDEX `cards_api_id_key`(`api_id`),
    INDEX `cards_api_id_idx`(`api_id`),
    INDEX `cards_name_idx`(`name`),
    INDEX `cards_set_name_idx`(`set_name`),
    INDEX `cards_source_idx`(`source`),
    INDEX `cards_card_type_idx`(`card_type`),
    INDEX `cards_rarity_idx`(`rarity`),
    INDEX `cards_market_price_idx`(`market_price`),
    INDEX `cards_tournament_legal_idx`(`tournament_legal`),
    INDEX `cards_featured_idx`(`featured`),
    INDEX `cards_primary_type_id_idx`(`primary_type_id`),
    INDEX `cards_secondary_type_id_idx`(`secondary_type_id`),
    INDEX `cards_set_id_idx`(`set_id`),
    INDEX `cards_rarity_id_idx`(`rarity_id`),
    INDEX `cards_subtype_id_idx`(`subtype_id`),
    INDEX `cards_supertype_id_idx`(`supertype_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `pricehistory` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `product_id` INTEGER NOT NULL,
    `retailer` VARCHAR(50) NOT NULL DEFAULT 'Unknown',
    `price` DECIMAL(10, 2) NOT NULL,
    `recorded_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `stock_status` VARCHAR(50) NULL,
    `store_quantity` INTEGER NULL,
    `ship_quantity` INTEGER NULL,

    INDEX `idx_product_retailer_date`(`product_id`, `retailer`, `recorded_at`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `products` (
    `product_id` INTEGER NOT NULL AUTO_INCREMENT,
    `retailer` VARCHAR(255) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `url` VARCHAR(255) NOT NULL,
    `image` VARCHAR(255) NULL,
    `screenshot` VARCHAR(255) NULL,
    `stock_status` VARCHAR(50) NOT NULL,
    `release_date` DATE NULL,
    `tcin` VARCHAR(20) NULL,

    UNIQUE INDEX `tcin`(`tcin`),
    PRIMARY KEY (`product_id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `watchlist` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `retailer_name` VARCHAR(255) NOT NULL,
    `product_url` VARCHAR(255) NULL,
    `product_title` VARCHAR(255) NOT NULL,
    `price` DECIMAL(10, 2) NOT NULL,
    `stock_quantity` INTEGER NULL,
    `stock_status` VARCHAR(50) NULL,
    `user_id` INTEGER NOT NULL,

    INDEX `user_id`(`user_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `waitlist` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `email` VARCHAR(255) NOT NULL,
    `phone_number` VARCHAR(20) NULL,
    `name` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
    `status` VARCHAR(50) NULL DEFAULT 'PENDING',
    `source` VARCHAR(50) NULL DEFAULT 'WEBSITE',
    `metadata` JSON NULL,

    UNIQUE INDEX `email`(`email`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `activitylog` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `userId` INTEGER NOT NULL,
    `action` VARCHAR(191) NOT NULL,
    `timestamp` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `ActivityLog_userId_fkey`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `reset_tokens` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `email` VARCHAR(255) NOT NULL,
    `token` VARCHAR(64) NOT NULL,
    `expires` DATETIME(0) NOT NULL,

    UNIQUE INDEX `token`(`token`),
    INDEX `idx_expires`(`expires`),
    INDEX `idx_token`(`token`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `user_cards` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `owner_id` INTEGER NOT NULL,
    `card_id` INTEGER NOT NULL,
    `condition` VARCHAR(50) NULL,
    `is_for_sale` BOOLEAN NOT NULL DEFAULT false,
    `sale_type` VARCHAR(50) NULL,
    `fixed_price` DECIMAL(10, 2) NULL,
    `reserve_price` DECIMAL(10, 2) NULL,
    `auction_end` DATETIME(0) NULL,
    `is_sold` BOOLEAN NOT NULL DEFAULT false,
    `notes` VARCHAR(255) NULL,
    `acquired_date` DATETIME(0) NULL,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),

    INDEX `owner_id`(`owner_id`),
    INDEX `card_id`(`card_id`),
    INDEX `user_cards_is_for_sale_idx`(`is_for_sale`),
    INDEX `user_cards_is_sold_idx`(`is_sold`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `bids` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `userCardId` INTEGER NOT NULL,
    `bidderId` INTEGER NOT NULL,
    `amount` DOUBLE NOT NULL,
    `is_active` BOOLEAN NOT NULL DEFAULT true,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `bids_bidderId_fkey`(`bidderId`),
    INDEX `bids_userCardId_fkey`(`userCardId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `card_transaction_history` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `userCardId` INTEGER NOT NULL,
    `fromUserId` INTEGER NULL,
    `toUserId` INTEGER NULL,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `action` VARCHAR(50) NOT NULL,
    `notes` VARCHAR(255) NULL,

    INDEX `card_transaction_history_fromUserId_fkey`(`fromUserId`),
    INDEX `card_transaction_history_toUserId_fkey`(`toUserId`),
    INDEX `card_transaction_history_userCardId_fkey`(`userCardId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `user_wallets` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `user_id` INTEGER NOT NULL,
    `balance` DECIMAL(10, 2) NOT NULL,
    `frozen_balance` DECIMAL(10, 2) NOT NULL,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `updated_at` DATETIME(0) NOT NULL,

    UNIQUE INDEX `user_wallets_user_id_key`(`user_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `wallet_transactions` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `user_id` INTEGER NOT NULL,
    `wallet_id` INTEGER NOT NULL,
    `transaction_type` VARCHAR(50) NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    `balance_before` DECIMAL(10, 2) NOT NULL,
    `balance_after` DECIMAL(10, 2) NOT NULL,
    `description` VARCHAR(255) NULL,
    `reference_type` VARCHAR(50) NOT NULL,
    `reference_id` INTEGER NULL,
    `admin_id` INTEGER NULL,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),

    INDEX `wallet_transactions_user_id_fkey`(`user_id`),
    INDEX `wallet_transactions_wallet_id_fkey`(`wallet_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `notifications` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `user_id` INTEGER NOT NULL,
    `type` VARCHAR(50) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `data` JSON NULL,
    `read` BOOLEAN NOT NULL DEFAULT false,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL,

    INDEX `notifications_user_id_read_idx`(`user_id`, `read`),
    INDEX `notifications_created_at_idx`(`created_at`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `price_history` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `card_id` INTEGER NOT NULL,
    `price` DECIMAL(10, 2) NOT NULL,
    `source` VARCHAR(50) NOT NULL DEFAULT 'manual',
    `recorded_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
    `metadata` JSON NULL,
    `created_at` DATETIME(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),

    INDEX `idx_card_date`(`card_id`, `recorded_at`),
    INDEX `idx_card_id`(`card_id`),
    INDEX `idx_recorded_at`(`recorded_at`),
    INDEX `idx_source`(`source`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
